def SumN(n):
    s=(n*(n+1))//2
    print(s)